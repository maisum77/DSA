#include<iostream>
using namespace std;
int main()
{
    int arr[5]={10,20,30,40,50};
    cout<<"---data---"<<endl;
    for (int j = 0; j <= 4; j++)
    {
        cout<<arr[j]<<" ";
    }
    return 0;
}